﻿//function openMyPage() {
//  console.log('kitty');
//  document.body.style.border = "5px solid red";
//  window.document.body.innerHTML = '<h1>cat</h1>';
//}

//browser.browserAction.onClicked.addListener(openMyPage);