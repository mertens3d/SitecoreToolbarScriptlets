﻿cd 'C:\projects\SitecoreToolbarScriptlets\Browser Addons\Firefox\HindSite'
web-ext run -t chromium  --verbose 
# -t firefox-desktop