﻿//function openMyPage() {
//  document.body.style.border = '10px solid green';
//}

console.log('here 77 - this gets loaded with each page');

//openMyPage();